angular.module('dashboard', ['ui.router', 'ngSanitize', 'ngTouch', 'ngAnimate'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/home');
        $stateProvider
            .state('home', {
                url: '/home',
                templateUrl: 'templates/home.html',
                controller: 'homeController'
            })
            .state('myClients', {
                url: '/myClients',
                templateUrl: 'templates/myClients.html',
                controller: 'homeController'
            })
            .state('allClients', {
                url: '/allClients',
                templateUrl: 'templates/allClients.html',
                controller: 'homeController'
            })
            .state('reports', {
                url: '/reports',
                templateUrl: 'templates/reports.html',
                controller: 'homeController'
            })
    })
    .run(function ($rootScope, $state) {
        $rootScope.$state = $state;
    });